
const db = idb.openDB('posts-store', 1, {
    upgrade(db) {
        db.createObjectStore('posts', {
            keyPath: 'id',
        }).createIndex('id', 'id');

        db.createObjectStore('sync-posts', {
            keyPath: 'id',
        }).createIndex('id', 'id');
    },
});

function writeData(st, data) {
    return db
        .then( dbPosts => {
            let tx = dbPosts.transaction(st, 'readwrite');
            let store = tx.objectStore(st);
            store.put(data);
            return tx.done;
        })
}

function readAllData(st) {
    return db
        .then( dbPosts => {
            let tx = dbPosts.transaction(st, 'readonly');
            let store = tx.objectStore(st);
            return store.getAll();
        })
}

function clearAllData(st) {
    return db
        .then( dbPosts => {
            let tx = dbPosts.transaction(st, 'readwrite');
            let store = tx.objectStore(st);
            store.clear();
            return tx.done;
        })
}

function deleteOneData(st, id) {
    db
        .then( dbPosts => {
            let tx = dbPosts.transaction(st, 'readwrite');
            let store = tx.objectStore(st);
            store.delete(id);
            return tx.done;
        })
        .then( () => {
            console.log('Data deleted ...');
            });
}

function deleteByTitle(st, title) {
    db
        .then( dbPosts => {
            var transaction = dbPosts.transaction(['posts'], 'readonly');
            var objectStore = transaction.objectStore('posts');
            console.log('displadatabyindex');
            var myIndex = objectStore.index('id');
            console.log(myIndex);
            myIndex.getAllKeys()
                .then(
                    res => {
                        console.log(res);
                        for(let i=0; i<res.length; i++) {
                            let value = myIndex.get(res[i])
                                .then( val => {
                                    if(val.title.includes(title)) {
                                        console.log(val.title);
                                        deleteOneData(st, res[i]);
                                    }

                                })
                        }

                    }
                )
        });
}
